<form action="" method="post">


    <input type="text" name="nom" id="">

    <button type="submit" class="btn btn-success">Enregistrer</button>
</form>