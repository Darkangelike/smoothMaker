


<h1><?= $cocktail['name'] ?></h1>
<p><strong>Ingredients : </strong><?= $cocktail['ingredients'] ?></p>

<img src="images/<?= $cocktail['image'] ?>" alt="">