<?php
 /*   
    $messages = [

        [
            "auteur"=> "Luc",
            "description"=> "salut "
        ],
        [
            "auteur"=> "Patricia",
            "description"=> " je sais pas quoi ecrire"
        ],
        [
            "auteur"=> "Anna",
            "description"=> "moi je sais"
        ],
        [
            "auteur"=> "Bobby",
            "description"=> "ce matin j'ai mangé une pomme"
        ],


    ];
 */
    // CONNECTION DB

require_once "db.php";

   // echo(mysqli_error($maConnection));

   // REQUETE SQL 

   if(
        isset($_GET['id'])
    && !empty($_GET['id'])

   ){
        $modeEdition = false;
        if( isset($_GET['edition'])){

            $modeEdition=true;
        }
    

        $id = htmlspecialchars($_GET['id']);

        $sql = "SELECT messages.id, messages.auteur, messages.description FROM messages WHERE id = '$id'";

            $resultat = mysqli_query($maConnection, $sql);

            $message = $resultat->fetch_assoc();


   }else {

            $maRequete = "SELECT * FROM messages";

            $messages = mysqli_query($maConnection, $maRequete);

   }


  


?>