<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voyage2000</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <link rel="stylesheet" href="style.css">
</head>
<body>
    
<nav class="navbar navbar-expand-lg navbar-dark bg-warning mb-5">
    <a href="index.php" class="navbar-brand">Voyage2000</a>
    <ul class="navbar-nav me-auto">

        <li class="nav-item">
                <form method="post">
                    <input type="text" name="user" placeholder="utilisateur">
                    <input type="text" name="password" id="" placeholder="Mot de passe">
                    <input class="btn btn-success" type="submit" value="Go">
                </form>
            </li>

    </ul>
    
</nav>

<div style="background-image:url('images/canada.png')" class="destination row m-5 flex-direction-column align-items-center justify-content-center">

        <h1>Canada</h1>
        <h2 style="color:red">3455 €</h2>
        <h3>19 Jours</h3>
        <h3>Pour 2 voyageurs</h3>



</div>
<div style="background-image:url('images/canada.png')" class="destination row m-5 flex-direction-column align-items-center justify-content-center">

        <h1>Canada</h1>
        <h2 style="color:red">3455 €</h2>
        <h3>19 Jours</h3>
        <h3>Pour 2 voyageurs</h3>



</div>
<div style="background-image:url('images/canada.png')" class="destination row m-5 flex-direction-column align-items-center justify-content-center">

        <h1>Canada</h1>
        <h2 style="color:red">3455 €</h2>
        <h3>19 Jours</h3>
        <h3>Pour 2 voyageurs</h3>



</div>
<div style="background-image:url('images/canada.png')" class="destination row m-5 flex-direction-column align-items-center justify-content-center">

        <h1>Canada</h1>
        <h2 style="color:red">3455 €</h2>
        <h3>19 Jours</h3>
        <h3>Pour 2 voyageurs</h3>



</div>


</body>
</html>