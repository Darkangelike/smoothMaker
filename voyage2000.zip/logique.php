<?php

$voyages = [

    [
        "destination"=> "Canada",
        "prix"=> 3455,
        "duree"=> 19,
        "image"=> "canada.png",
        "personnes"=> 2,
        "transport"=>"avion"

    ],
    [
        "destination"=> "Mexique",
        "prix"=> 2355,
        "duree"=> 25,
        "image"=> "mexique.png",
        "personnes"=> 3,
        "transport"=>"avion"

    ],
  

];


?>